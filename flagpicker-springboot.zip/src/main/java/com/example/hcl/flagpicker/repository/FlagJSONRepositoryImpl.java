package com.example.hcl.flagpicker.repository;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Repository;

import com.example.hcl.flagpicker.controller.FlagAPIController;
import com.example.hcl.flagpicker.exception.DataNotFoundException;
import com.example.hcl.flagpicker.model.Continent;
import com.example.hcl.flagpicker.model.Country;
import com.fasterxml.jackson.databind.ObjectMapper;

@ConditionalOnProperty(name = "repository.selection", havingValue = "json", matchIfMissing = true)
@Repository
public class FlagJSONRepositoryImpl implements IFlagRepository {

	public static final Logger logger = LoggerFactory.getLogger(FlagJSONRepositoryImpl.class);

	Continent[] continents;

	public FlagJSONRepositoryImpl() throws IOException, JSONException {
		logger.debug("Initilializing JSON Repository");
		ObjectMapper mapper = new ObjectMapper();
		continents = mapper.readValue(new File("./continents.json"), Continent[].class);

	}

	public List getAllFlags() throws JSONException {
		logger.debug("Repo getAll methods");
		return Arrays.asList(continents);
	}

	public Continent getContinentData(String continentName) {

		logger.debug("getContinentData method ::" + continentName);
		for (Object object : continents) {
			Continent continent = (Continent) object;
			if (continent.getContinent().equalsIgnoreCase(continentName)) {
				logger.debug("continent found" + continent);
				return continent;
			}
		}
		logger.debug("No continent found with name " + continentName);
		throw new DataNotFoundException("No data found for continent "+ continentName);
	}

	public String getCountryFlag(String countryName) {

		logger.debug("getCountryFlag:" + countryName);
		for (Object object : continents) {
			Continent continent = (Continent) object;
			Country country = continent.getCountry(countryName);
			if (country != null) {
				logger.debug("country found" + country);
				return country.getFlag();
			}
		}
		logger.debug("No country found" + countryName);
	    throw new DataNotFoundException("No data found for country "+ countryName);
	}

}
